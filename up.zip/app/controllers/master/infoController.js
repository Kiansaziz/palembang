(function(){

    app.controller('infoController', function($scope){

      // script goes here

    });



}());
